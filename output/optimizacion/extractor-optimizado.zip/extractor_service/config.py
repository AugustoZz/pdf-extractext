"""Configuración por variables de entorno (12-Factor III)."""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    MAX_FILE_SIZE_MB: int = 10
    # Procesos que extraen en paralelo; con 1 CPU por réplica, más no suma.
    WORKERS: int = 1
    # Hasta 32 PDFs en recepción/cola: 320 MiB, más buffers y el proceso de trabajo.
    MAX_INFLIGHT: int = 32
    # Espera máxima para adquirir cada etapa (recepción y CPU), no un timeout
    # total de la petición. El PDF en procesamiento ocupa su propia etapa.
    QUEUE_TIMEOUT_S: float = 20.0

    @property
    def max_file_bytes(self) -> int:
        return self.MAX_FILE_SIZE_MB * 1024 * 1024


settings = Settings()
