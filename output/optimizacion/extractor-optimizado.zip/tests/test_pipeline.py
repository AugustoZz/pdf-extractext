"""Uploads must overlap CPU work without creating unbounded PDF buffers."""
import asyncio

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from extractor_service import main
from extractor_service.admission import Admission
from extractor_service.pdf_extractor import ExtractionResult


def test_second_upload_is_received_while_first_pdf_is_processing(monkeypatch):
    async def scenario():
        loop = asyncio.get_running_loop()
        first_result = loop.create_future()
        processing = asyncio.Event()
        received = asyncio.Event()
        result = ExtractionResult(content="text", page_count=1)

        def executor(*args):
            if not processing.is_set():
                processing.set()
                return first_result
            future = loop.create_future()
            future.set_result(result)
            return future

        def request(uploaded=None):
            async def receive():
                if uploaded:
                    uploaded.set()
                return {"type": "http.request", "body": b"%PDF", "more_body": False}
            return Request({"type": "http", "app": main.app}, receive)

        monkeypatch.setattr(main, "_admission", Admission(1, 1))
        monkeypatch.setattr(main, "_ingress", Admission(2, 1))
        monkeypatch.setattr(main.app.state, "pool", object(), raising=False)
        monkeypatch.setattr(loop, "run_in_executor", executor)
        first = asyncio.create_task(main.extract_pdf(request()))
        await asyncio.wait_for(processing.wait(), 1)
        second = asyncio.create_task(main.extract_pdf(request(received)))
        try:
            await asyncio.wait_for(received.wait(), 1)
            assert not first_result.done()
        finally:
            first_result.set_result(result)
            responses = await asyncio.gather(first, second)
        assert responses == [{"content": "text", "page_count": 1}] * 2

    asyncio.run(scenario())


def test_full_ingress_rejects_without_receiving_another_pdf(monkeypatch):
    async def scenario():
        ingress = Admission(1, 0.01)
        monkeypatch.setattr(main, "_ingress", ingress)

        async def receive():
            pytest.fail("A full ingress must not allocate another PDF buffer")

        request = Request({"type": "http", "app": main.app}, receive)
        async with ingress.slot():
            with pytest.raises(HTTPException) as error:
                await main.extract_pdf(request)
            assert error.value.status_code == 503

    asyncio.run(scenario())


def test_oversized_upload_releases_ingress(monkeypatch):
    async def scenario():
        ingress = Admission(1, 0.01)
        monkeypatch.setattr(main, "_ingress", ingress)
        monkeypatch.setattr(main.settings, "MAX_FILE_SIZE_MB", 1)

        async def receive():
            return {"type": "http.request", "body": b"x" * (1024 * 1024 + 1), "more_body": False}

        with pytest.raises(HTTPException) as error:
            await main.extract_pdf(Request({"type": "http", "app": main.app}, receive))
        assert error.value.status_code == 413
        async with ingress.slot():
            pass

    asyncio.run(scenario())
